import { researchEntries } from "@/lib/research";
import { catalogSlug } from "@/lib/catalog-naming";
import Link from "next/link";
import styles from "./product-reviews.module.css";
import { ArrowIcon } from "./arrow-icon";

export function ProductReviews({ slug, name }: { slug: string; name: string }) {
  const researchSlug = catalogSlug(slug);
  const research = researchEntries.find((entry) => entry.slug === researchSlug);
  return <div className={styles.reviews}>
    {research && <section id="scientific-review" className={styles.science} aria-labelledby="scientific-review-heading">
      <div className={styles.scienceHeading}><p className={styles.eyebrow}>A closer reading</p><h2 id="scientific-review-heading">The scientific review.</h2><p>One selected primary paper, with its findings and limits. A starting point for reading, not a complete assessment of the evidence.</p></div>
      <article className={styles.paper}>
        <div className={styles.tags}><span>{research.evidence === "human" ? "Human study" : "Preclinical study"}</span>{research.related && <span>Related-compound evidence</span>}<span>{research.year}</span></div>
        <h3>{research.focus}</h3><p className={styles.model}>{research.model}</p>
        <div className={styles.findings}><div><h4>What the researchers observed</h4><p>{research.finding}</p></div><div><h4>What this does not establish</h4><p>{research.limitation}</p></div></div>
        <div className={styles.source}><p>{research.authors} · <cite>{research.journal}</cite> · {research.year}</p><a href={research.source}><span>Read the primary paper</span><ArrowIcon /><small>{research.sourceId}</small></a></div>
      </article>
      <Link href={`/science/${researchSlug}`} className={styles.libraryLink}>Explore all {researchEntries.filter((entry) => entry.slug === researchSlug).length} {name} studies <ArrowIcon /></Link>
    </section>}
  </div>;
}
